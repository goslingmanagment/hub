import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import {
  acquirePageSyncLease, completePageSync, getCheckpoint, getPageSyncState,
  retryPageSync, runWithPageSyncExecutionContext, scheduleDuePageSync,
} from "@agency_hub_core/db";
import { executeFanEarningsChunk } from "../apps/runtime/src/services/sync/fan-earnings.ts";
import { resetIntegrationDatabase, startTestDatabase, type StartedTestDatabase } from "./helpers/db.ts";
import { earningsShadowAdapter, type EarningsVisit } from "./helpers/earnings-shadow-adapter.ts";
import { earningsShadowFixture } from "./helpers/earnings-shadow-fixture.ts";

let db: StartedTestDatabase;
beforeAll(async () => { db = await startTestDatabase(); }, 120_000);
afterAll(async () => { await db?.stop(); });
beforeEach(async () => { await resetIntegrationDatabase(db.pool); });

describe("earnings completion before scheduled-generation settlement", () => {
  it.each([false, true])("repeats the same walk only after settlement failure: %s", async (failSettlement) => {
    const f = await earningsShadowFixture(db, false);
    const now = new Date("2026-09-14T12:00:00Z");
    const visits: EarningsVisit[] = [];
    f.app.adapter = earningsShadowAdapter(visits);
    // Seed a quiescent page; the real scheduler admits the earnings generation.
    await db.pool.query(`update page_sync_states
      set applied_seq = request_seq, status = 'paused' where page_id = $1`, [f.page.id]);
    await db.pool.query(`update page_sync_states set status = 'idle', last_scheduled_slot = -1
      where page_id = $1 and stream = 'fan_earnings'`, [f.page.id]);
    await scheduleDuePageSync(db.db, { pageId: f.page.id, now });

    async function acquire(token: string, at = now) {
      const lease = await acquirePageSyncLease(db.db, {
        pageId: f.page.id, workerId: "earnings-settlement-test",
        leaseToken: token, leaseTtlMs: 120_000, now: at,
      });
      if (!lease || lease.stream !== "fan_earnings" || lease.leasedSeq === null) {
        throw new Error("Expected the scheduled earnings lease");
      }
      return lease;
    }
    async function walk(lease: Awaited<ReturnType<typeof acquire>>) {
      return runWithPageSyncExecutionContext({
        pageId: f.page.id, stream: lease.stream,
        requestSeq: lease.leasedSeq!, leaseToken: lease.leaseToken!,
      }, async () => executeFanEarningsChunk(f.app, await f.chunkInput()));
    }
    function settle(lease: Awaited<ReturnType<typeof acquire>>) {
      return completePageSync(db.db, {
        pageId: f.page.id, stream: lease.stream,
        requestSeq: lease.leasedSeq!, leaseToken: lease.leaseToken!, now,
      });
    }

    const first = await acquire("before-settlement-failure");
    expect(first.requestSource).toBe("scheduled");
    expect(await walk(first)).toMatchObject({ satisfied: true, stats: { walkCompleted: true, fansFetched: 2 } });
    const completed = await getCheckpoint(db.db, f.page.id, "fan_earnings");
    expect(completed?.state).toEqual({ cursorFanId: 0, completedAt: expect.any(String) });
    const oneWalk = ["fan-a", "fan-b"].flatMap((fanRef) => [
      { fanRef, window: "lifetime" }, { fanRef, window: "monthly" },
    ]);
    expect(visits).toEqual(oneWalk);

    if (!failSettlement) {
      expect(await settle(first)).toBe(true);
      await scheduleDuePageSync(db.db, { pageId: f.page.id, now });
      expect(await getPageSyncState(db.db, f.page.id, "fan_earnings")).toMatchObject({
        requestSeq: first.requestSeq, appliedSeq: first.requestSeq,
        lastScheduledSlot: first.lastScheduledSlot, status: "idle",
      });
      expect(visits).toEqual(oneWalk);
      return;
    }

    // The handler's checkpoint has committed; fail only the later settlement.
    await db.pool.query(`create function reject_earnings_settlement() returns trigger
      language plpgsql as $$ begin
        if new.stream = 'fan_earnings' and new.applied_seq > old.applied_seq then
          raise exception 'injected earnings settlement failure';
        end if;
        return new;
      end $$;
      create trigger reject_earnings_settlement before update on page_sync_states
      for each row execute function reject_earnings_settlement()`);
    try {
      await expect(settle(first)).rejects.toMatchObject({
        cause: { message: "injected earnings settlement failure", code: "P0001" },
      });
    } finally {
      await db.pool.query(`drop trigger reject_earnings_settlement on page_sync_states;
        drop function reject_earnings_settlement()`);
    }
    expect((await getCheckpoint(db.db, f.page.id, "fan_earnings"))?.state).toEqual(completed?.state);
    expect(await getPageSyncState(db.db, f.page.id, "fan_earnings")).toMatchObject({
      requestSeq: first.requestSeq, appliedSeq: first.appliedSeq,
      lastScheduledSlot: first.lastScheduledSlot, status: "running",
    });
    const retryAt = new Date(now.getTime() + 60_000);
    expect(await retryPageSync(db.db, {
      pageId: f.page.id, stream: first.stream,
      requestSeq: first.leasedSeq!, leaseToken: first.leaseToken!,
      retryKind: "transport", retryAt, now,
      errorCode: "injected_settlement_failure", errorSummary: "test database settlement failed",
    })).toMatchObject({ updated: true, retried: true });
    const retry = await acquire("after-settlement-failure", retryAt);
    expect(retry).toMatchObject({
      requestSeq: first.requestSeq, leasedSeq: first.leasedSeq,
      lastScheduledSlot: first.lastScheduledSlot,
    });
    expect(await walk(retry)).toMatchObject({ satisfied: true, stats: { walkCompleted: true, fansFetched: 2 } });
    expect(await settle(retry)).toBe(true);
    expect(visits).toEqual([...oneWalk, ...oneWalk]);
    const captured = await db.pool.query(`select o.kind, count(*)::int n from observations o
      where o.account_id = $1 group by o.kind order by o.kind`, [f.page.id]);
    expect(captured.rows).toEqual([
      { kind: "fan_earnings_monthly", n: 4 }, { kind: "fan_earnings_stats", n: 4 },
    ]);
  });
});
