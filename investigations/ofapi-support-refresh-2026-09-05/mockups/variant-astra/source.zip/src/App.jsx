import React, { useEffect, useRef, useState } from "react";
import {
  Home,
  UserRound,
  Coins,
  Settings,
  ChevronDown,
  ChevronRight,
  History,
  Pause,
  Play,
  ArrowUpRight,
  Info,
  Check,
  X,
  Menu,
  UsersRound,
  MessageSquare,
  PanelsTopLeft,
  Images,
  UserRoundSearch,
  ChartNoAxesCombined,
  Webhook,
  CheckCircle2,
  LoaderCircle,
  Globe,
  SlidersHorizontal,
} from "lucide-react";
import "@fontsource/inter/400.css";
import "@fontsource/inter/500.css";
import "@fontsource/inter/600.css";
import "@fontsource/inter/700.css";
import { Button } from "./ui.jsx";
import {
  categories,
  STORAGE_KEY,
  loadState,
  num,
  credits,
  policyLabel,
  backgroundSpent,
} from "./data.js";
import {
  CategorySheet,
  BudgetDialog,
  PauseDialog,
  EventsDialog,
  HistoryDialog,
  SpendDialog,
  JobDialog,
  ReviewDialog,
} from "./panels.jsx";

export const categoryIcons = {
  users: UsersRound,
  chat: MessageSquare,
  posts: PanelsTopLeft,
  image: Images,
  visitors: UserRoundSearch,
  traffic: ChartNoAxesCombined,
};
const timeNow = () =>
  `Сегодня, ${new Intl.DateTimeFormat("ru-RU", { hour: "2-digit", minute: "2-digit" }).format(new Date())}`;

export function App() {
  const [state, setState] = useState(loadState);
  const [pageId, setPageId] = useState("lora-of");
  const [categoryId, setCategoryId] = useState(null);
  const [modal, setModal] = useState(null);
  const [review, setReview] = useState(null);
  const [busy, setBusy] = useState(false);
  const [toast, setToast] = useState(null);
  const [mobileNav, setMobileNav] = useState(false);
  const timers = useRef([]);
  const page = state.pages[pageId];
  const spent = backgroundSpent(page);
  const paused = state.globalPaused || page.paused;
  const exhausted = spent >= page.limit;
  const category = categories.find((c) => c.id === categoryId);
  const active = categories.filter(
    (c) => page.policies[c.id].mode !== "off",
  ).length;
  const pageJobs = state.jobs.filter((j) => j.pageId === pageId);
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch {
      /* Preview works in memory if storage is unavailable. */
    }
  }, [state]);
  useEffect(() => {
    if (!toast) return;
    const timer = setTimeout(() => setToast(null), 4500);
    return () => clearTimeout(timer);
  }, [toast]);
  useEffect(() => () => timers.current.forEach(clearTimeout), []);
  function changePage(id) {
    setPageId(id);
    setCategoryId(null);
    setMobileNav(false);
  }
  function applyReview() {
    if (busy || !review) return;
    setBusy(true);
    const change = review;
    timers.current.push(
      setTimeout(() => {
        setState((old) => {
          const next = structuredClone(old);
          change.apply(next);
          next.history.unshift({
            id: crypto.randomUUID(),
            time: timeNow(),
            scope: change.scope,
            title: change.title,
            detail:
              change.historyDetail ||
              change.diffs.map((d) => `${d[0]}: ${d[2]}`).join(" · "),
            actor: "Дмитрий",
          });
          return next;
        });
        setReview(null);
        setModal(null);
        setCategoryId(null);
        setBusy(false);
        setToast(change.success || "Изменения применены");
        if (change.job)
          timers.current.push(
            setTimeout(() => {
              setState((old) => {
                const next = structuredClone(old);
                const job = next.jobs.find((j) => j.id === change.job.id);
                if (job) {
                  job.status = "done";
                  const stat = next.pages[job.pageId].stats[job.categoryId];
                  stat.manual += job.cost;
                  stat.updated = "Только что";
                }
                return next;
              });
              setToast(
                "Пример разовой задачи завершён. Расход учтён отдельно от фона",
              );
            }, 1800),
          );
      }, 500),
    );
  }
  function reviewPolicy(draft) {
    const id = pageId;
    const cid = category.id;
    const before = page.policies[cid];
    const diffs = [];
    if (policyLabel(before) !== policyLabel(draft))
      diffs.push(["Режим", policyLabel(before), policyLabel(draft)]);
    if (before.limit !== Number(draft.limit) && draft.mode !== "off")
      diffs.push([
        "Лимит категории",
        `${credits(before.limit)} в день`,
        `${credits(draft.limit)} в день`,
      ]);
    setReview({
      title: "Изменить сбор данных",
      scope: `${id} · ${category.name}`,
      diffs,
      note:
        draft.mode === "off"
          ? "Новые запросы для этой категории прекратятся. Сохранённые данные останутся доступны."
          : "Настройка начнёт действовать после применения. Старая история и сами медиафайлы автоматически не загрузятся.",
      cost:
        draft.mode === "schedule"
          ? `До ${credits(draft.limit)} в день в пределах общего лимита фона ${credits(page.limit)} Фактическая стоимость первого сбора пока неизвестна.`
          : draft.mode === "manual"
            ? `Сбор запускается по запросу. Предел для категории — ${credits(draft.limit)} в день; расход не входит в лимит фонового сбора.`
            : "Регулярный сбор не будет расходовать кредиты.",
      apply: (next) => {
        next.pages[id].policies[cid] = {
          ...draft,
          limit: Number(draft.limit),
          version: before.version + 1,
        };
      },
    });
  }
  return (
    <div className="app-shell">
      {mobileNav && (
        <button
          className="nav-shade"
          aria-label="Закрыть меню"
          onClick={() => setMobileNav(false)}
        />
      )}
      <aside className={`sidebar ${mobileNav ? "is-open" : ""}`}>
        <div className="brand-row">
          <div className="wordmark">
            <span>Agency</span>Hub
          </div>
          <button
            className="icon-button mobile-only"
            aria-label="Закрыть навигацию"
            onClick={() => setMobileNav(false)}
          >
            <X size={20} />
          </button>
        </div>
        <nav aria-label="Основная навигация">
          <div className="nav-item muted-nav">
            <Home size={19} />
            <span>Overview</span>
          </div>
          <div className="nav-divider" />
          <div className="nav-label">РАБОЧЕЕ ПРОСТРАНСТВО</div>
          <div className="nav-item model-label">
            <UserRound size={19} />
            <span>Lora</span>
            <ChevronDown size={14} />
          </div>
          <div className="page-nav">
            {Object.keys(state.pages).map((id) => (
              <button
                key={id}
                className={pageId === id ? "selected" : ""}
                onClick={() => changePage(id)}
                aria-current={pageId === id ? "true" : undefined}
              >
                <span className="page-dot" />
                {id}
              </button>
            ))}
          </div>
          <div className="nav-divider" />
          <button
            className="nav-item"
            onClick={() => {
              setModal({ type: "spend" });
              setMobileNav(false);
            }}
          >
            <Coins size={19} />
            <span>OFAPI Credits</span>
          </button>
          <div className="nav-item nav-active" aria-current="page">
            <Settings size={19} />
            <span>Settings</span>
          </div>
        </nav>
        <div className="sidebar-footer">
          <div className="avatar">Д</div>
          <div>
            <strong>Дмитрий</strong>
            <span>Владелец</span>
          </div>
          <span className="owner-badge">Owner</span>
        </div>
      </aside>
      <div className="app-main">
        <header className="topbar">
          <button
            className="icon-button mobile-only"
            aria-label="Открыть меню"
            onClick={() => setMobileNav(true)}
          >
            <Menu size={20} />
          </button>
          <div className="breadcrumbs">
            <span>Настройки</span>
            <ChevronRight size={13} />
            <span>Сбор данных</span>
          </div>
          <span className="example-badge">
            <span />
            Пример данных
          </span>
        </header>
        <main className="page-content">
          <div className="page-heading">
            <div>
              <h1>Сбор данных</h1>
              <p>Выбирайте, что обновлять и сколько тратить.</p>
            </div>
            <Button
              aria-label="История изменений"
              onClick={() => setModal({ type: "history" })}
            >
              <History size={16} />
              <span>История изменений</span>
            </Button>
          </div>
          <div className="page-toolbar">
            <div className="account-picker">
              <label className="select-wrap">
                <UserRound size={16} />
                <select
                  aria-label="Страница OnlyFans"
                  value={pageId}
                  onChange={(e) => changePage(e.target.value)}
                >
                  {Object.keys(state.pages).map((id) => (
                    <option key={id}>{id}</option>
                  ))}
                </select>
                <ChevronDown size={15} />
              </label>
              <span className="platform-badge">OnlyFans</span>
            </div>
            <Button onClick={() => setModal({ type: "pause" })}>
              {paused ? <Play size={15} /> : <Pause size={15} />}
              <span>{paused ? "Возобновить фон" : "Пауза фона"}</span>
            </Button>
          </div>
          <section
            className={`budget-summary ${paused || exhausted ? "budget-paused" : ""}`}
            aria-label="Бюджет фонового сбора"
          >
            <div className="budget-top">
              <div>
                <span className="budget-label">Фоновый сбор сегодня</span>
                <div className="budget-amount">
                  <strong>{num(spent)}</strong>
                  <span>/ {num(page.limit)} кр.</span>
                  <span
                    className={`status-pill ${paused || exhausted ? "is-paused" : ""}`}
                  >
                    {paused || exhausted ? (
                      <Pause size={11} />
                    ) : (
                      <span className="status-dot" />
                    )}
                    {paused
                      ? "На паузе"
                      : exhausted
                        ? "Лимит достигнут"
                        : "В пределах лимита"}
                  </span>
                </div>
              </div>
              <button
                className="text-button"
                onClick={() => setModal({ type: "budget" })}
              >
                <SlidersHorizontal size={14} />
                Изменить лимит
              </button>
            </div>
            <div
              className="budget-track"
              role="progressbar"
              aria-label="Расход фонового бюджета"
              aria-valuenow={spent}
              aria-valuemin={0}
              aria-valuemax={Math.max(page.limit, spent)}
            >
              <div
                style={{
                  width: `${Math.min(100, (spent / page.limit) * 100)}%`,
                }}
              />
            </div>
            <div className="budget-bottom">
              <span>
                {paused
                  ? state.globalPaused
                    ? "Фон остановлен для всех OF-страниц"
                    : "Фон остановлен для этой страницы"
                  : exhausted
                    ? "Новые фоновые запросы остановлены до следующего дня"
                    : `Осталось ${credits(Math.max(0, page.limit - spent))} на новые запросы`}
              </span>
              <span>День по UTC</span>
            </div>
            <div className="budget-note">
              <Info size={14} />
              <span>Ручные обновления и события учитываются отдельно.</span>
              <button onClick={() => setModal({ type: "spend" })}>
                Весь расход <ArrowUpRight size={12} />
              </button>
            </div>
          </section>
          <div className="section-heading">
            <h2>Данные страницы</h2>
            <span>
              {active} из {categories.length} категорий включены
            </span>
          </div>
          <div className="collection-table">
            <div className="table-head" aria-hidden="true">
              <span>Данные</span>
              <span>Режим сбора</span>
              <span>Сегодня, всего</span>
              <span />
            </div>
            {categories.map((cat) => {
              const policy = page.policies[cat.id];
              const stat = page.stats[cat.id];
              const Icon = categoryIcons[cat.icon];
              const off = policy.mode === "off";
              return (
                <button
                  key={cat.id}
                  className={`collection-row ${categoryId === cat.id ? "row-selected" : ""}`}
                  onClick={() => setCategoryId(cat.id)}
                  aria-label={`Настроить: ${cat.name}`}
                >
                  <div className="category-cell">
                    <span className="category-icon">
                      <Icon size={21} strokeWidth={1.6} />
                    </span>
                    <div>
                      <strong>{cat.name}</strong>
                      <span className="category-description">
                        {cat.description}
                      </span>
                      <span className={`freshness ${off ? "archived" : ""}`}>
                        {off ? (
                          stat.count ? (
                            <>
                              <Check size={12} />
                              Сохранённая история доступна
                            </>
                          ) : (
                            <>Пока не собирается</>
                          )
                        ) : (
                          <>
                            <span className="status-dot" />
                            {stat.updated
                              ? `Обновлено ${stat.updated}`
                              : "Ожидает первого запуска"}
                          </>
                        )}
                      </span>
                    </div>
                  </div>
                  <div className={`mode-cell ${off ? "mode-off" : ""}`}>
                    <span>{policyLabel(policy)}</span>
                    {!off && (
                      <small>
                        {policy.mode === "schedule" && (paused || exhausted)
                          ? "Фон на паузе"
                          : `До ${credits(policy.limit)} в день`}
                      </small>
                    )}
                  </div>
                  <div
                    className={`spend-cell ${stat.background + stat.manual === 0 ? "no-spend" : ""}`}
                  >
                    <span>{credits(stat.background + stat.manual)}</span>
                    <small className="mobile-only">сегодня</small>
                  </div>
                  <ChevronRight className="row-chevron" size={17} />
                </button>
              );
            })}
          </div>
          <button
            className="events-summary"
            onClick={() => setModal({ type: "events" })}
          >
            <span className="events-icon">
              <Webhook size={26} strokeWidth={1.5} />
            </span>
            <span className="events-copy">
              <span className="events-title">
                События OFAPI{" "}
                <span className="scope-badge">
                  <Globe size={11} />
                  Все OF-страницы
                </span>
              </span>
              <span className="events-description">
                Сообщения, покупки, статусы и другие события в реальном времени
              </span>
            </span>
            <span className="events-link">
              Настроить
              <ArrowUpRight size={15} />
            </span>
          </button>
          <div className="page-footnote">
            <Info size={15} />
            <span>
              Выключение сбора сохраняет архив. Загрузка истории и файлов
              запускается отдельно.
            </span>
          </div>
          {pageJobs.length > 0 && (
            <section className="jobs-section">
              <div className="section-heading">
                <h2>Разовые задачи</h2>
                <span>Отдельный лимит на каждый запуск</span>
              </div>
              {pageJobs.map((job) => (
                <div className="job-row" key={job.id}>
                  {job.status === "done" ? (
                    <CheckCircle2 size={18} className="green" />
                  ) : (
                    <LoaderCircle size={18} className="spin" />
                  )}
                  <div>
                    <strong>{job.title}</strong>
                    <span>{job.scopeText}</span>
                  </div>
                  <span className="job-status">
                    {job.status === "done"
                      ? `Выполнено · ${credits(job.cost)}`
                      : "Выполняется…"}
                  </span>
                </div>
              ))}
            </section>
          )}
        </main>
      </div>
      {category && (
        <CategorySheet
          key={`${pageId}-${category.id}`}
          category={category}
          pageId={pageId}
          page={page}
          paused={paused || exhausted}
          close={() => setCategoryId(null)}
          onReview={reviewPolicy}
          onJob={(kind) => setModal({ type: "job", kind, category })}
          jobs={pageJobs.filter((j) => j.categoryId === category.id)}
        />
      )}
      {modal?.type === "budget" && (
        <BudgetDialog
          page={page}
          pageId={pageId}
          close={() => setModal(null)}
          review={setReview}
        />
      )}
      {modal?.type === "pause" && (
        <PauseDialog
          state={state}
          pageId={pageId}
          close={() => setModal(null)}
          review={setReview}
        />
      )}
      {modal?.type === "events" && (
        <EventsDialog
          events={state.events}
          close={() => setModal(null)}
          review={setReview}
        />
      )}
      {modal?.type === "history" && (
        <HistoryDialog history={state.history} close={() => setModal(null)} />
      )}
      {modal?.type === "spend" && (
        <SpendDialog page={page} pageId={pageId} close={() => setModal(null)} />
      )}
      {modal?.type === "job" && (
        <JobDialog
          kind={modal.kind}
          category={modal.category}
          pageId={pageId}
          close={() => setModal(null)}
          review={setReview}
        />
      )}
      {review && (
        <ReviewDialog
          review={review}
          close={() => {
            if (!busy) setReview(null);
          }}
          apply={applyReview}
          busy={busy}
        />
      )}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={18} />
          <span>{toast}</span>
          <button
            aria-label="Закрыть уведомление"
            onClick={() => setToast(null)}
          >
            <X size={16} />
          </button>
        </div>
      )}
    </div>
  );
}
