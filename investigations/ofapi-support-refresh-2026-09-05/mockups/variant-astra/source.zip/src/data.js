export const STORAGE_KEY = "agencyhub-collection-page-20260905-v1";
export const TODAY = "2026-09-05";
export const categories = [
  {
    id: "audience",
    name: "Аудитория",
    description: "Подписчики и состояние подписки",
    icon: "users",
    limit: 120,
    purpose: "Понимать, кто подписан на страницу и как меняется аудитория.",
    contents: [
      "Профили подписчиков и статусы подписок",
      "Изменения аудитории с момента включения",
    ],
  },
  {
    id: "messages",
    name: "Сообщения",
    description: "Чаты и массовые сообщения",
    icon: "chat",
    limit: 50,
    purpose:
      "Обновлять сообщения, когда они нужны для работы в чате. Отправка сообщений управляется отдельно.",
    contents: [
      "Текст и сведения о сообщениях",
      "Связи с медиа без скачивания файлов",
    ],
    manualOnly: true,
  },
  {
    id: "posts",
    name: "Посты и комментарии",
    description: "Публикации и обсуждения",
    icon: "posts",
    limit: 20,
    purpose:
      "Сохранять новые публикации и обсуждения для поиска и работы с контентом.",
    contents: [
      "Новые посты, комментарии и реакции",
      "Ссылки на медиа без скачивания файлов",
    ],
  },
  {
    id: "vault",
    name: "Каталог медиа",
    description: "Описания файлов и связи с контентом",
    icon: "image",
    limit: 20,
    purpose:
      "Находить медиа и видеть, где они используются. Каталог хранит сведения о файлах.",
    contents: [
      "Названия, типы и размеры медиа",
      "Связи с публикациями и сообщениями",
    ],
  },
  {
    id: "visitors",
    name: "Посетители профиля",
    description: "Дневная статистика посещений",
    icon: "visitors",
    limit: 15,
    purpose:
      "Отслеживать посещаемость страницы по дням. Экспорт не содержит список конкретных посетителей.",
    contents: [
      "Дневные агрегаты посещений",
      "Показатели, доступные в экспорте OFAPI",
    ],
  },
  {
    id: "traffic",
    name: "Источники трафика",
    description: "Tracking links и Smart Links",
    icon: "traffic",
    limit: 20,
    purpose: "Сравнивать результаты ссылок и источников привлечения аудитории.",
    contents: [
      "Доступная статистика переходов по ссылкам",
      "Агрегаты tracking links и Smart Links",
    ],
  },
];
export const modes = {
  off: "Выключено",
  manual: "По запросу",
  schedule: "По расписанию",
};
export const cadences = {
  daily: "Раз в день",
  six: "Каждые 6 часов",
  hourly: "Каждый час",
};
export const eventOptions = [
  {
    id: "online",
    name: "Статус онлайн",
    description: "Присутствие пользователей в чатах",
    count: 420,
    cost: 4.2,
  },
  {
    id: "typing",
    name: "Набор сообщения",
    description: "Индикатор «печатает» в чате",
    count: 180,
    cost: 1.8,
  },
  {
    id: "expired",
    name: "Истечение подписки",
    description: "Изменения статуса подписчиков",
    count: 0,
    cost: 0,
  },
  {
    id: "likes",
    name: "Реакции на контент",
    description: "Новые отметки «нравится»",
    count: 0,
    cost: 0,
  },
];
export const exampleFiles = [
  { id: "video", name: "welcome-video.mp4", size: 2 },
  { id: "photo", name: "preview-photo.jpg", size: 0.5 },
  { id: "voice", name: "voice-message.mp3", size: 1 },
];
export const num = (value) =>
  new Intl.NumberFormat("ru-RU", { maximumFractionDigits: 1 }).format(value);
export const credits = (value) => `${num(value)} кр.`;
export const validLimit = (value) =>
  Number.isSafeInteger(Number(value)) &&
  Number(value) > 0 &&
  Number(value) <= 1000000;
export const policyLabel = (policy) =>
  policy.mode === "schedule" ? cadences[policy.cadence] : modes[policy.mode];
export const backgroundSpent = (page) =>
  Object.values(page.stats).reduce((sum, item) => sum + item.background, 0);
export const manualSpent = (page) =>
  Object.values(page.stats).reduce((sum, item) => sum + item.manual, 0);
function makePage(vip = false) {
  const policies = Object.fromEntries(
    categories.map((c) => [
      c.id,
      { mode: "off", cadence: "daily", limit: c.limit, version: 1 },
    ]),
  );
  policies.messages.mode = "manual";
  if (!vip)
    policies.audience = {
      mode: "schedule",
      cadence: "six",
      limit: 120,
      version: 1,
    };
  const stats = Object.fromEntries(
    categories.map((c) => [
      c.id,
      { background: 0, manual: 0, count: 0, updated: null },
    ]),
  );
  stats.messages = {
    background: 0,
    manual: vip ? 6 : 22,
    count: vip ? 430 : 1824,
    updated: "2 мин назад",
  };
  if (!vip) {
    stats.audience = {
      background: 52,
      manual: 0,
      count: 4356,
      updated: "8 мин назад",
    };
    stats.posts = {
      background: 0,
      manual: 0,
      count: 128,
      updated: "2 сентября",
    };
    stats.vault = {
      background: 0,
      manual: 0,
      count: 933,
      updated: "2 сентября",
    };
  }
  return { limit: vip ? 150 : 300, paused: false, policies, stats };
}
export function initialState() {
  return {
    version: 1,
    globalPaused: false,
    pages: { "lora-of": makePage(), "lora-vip-of": makePage(true) },
    events: { online: true, typing: true, expired: false, likes: false },
    jobs: [],
    history: [
      {
        id: "seed1",
        time: "Сегодня, 09:40",
        scope: "lora-of · Аудитория",
        title: "Включён сбор каждые 6 часов",
        detail: "Лимит категории: 120 кр. в день",
        actor: "Дмитрий",
      },
      {
        id: "seed2",
        time: "Сегодня, 09:35",
        scope: "lora-of",
        title: "Установлен лимит фона 300 кр. в день",
        detail: "Отдельно от ручных обновлений и событий",
        actor: "Дмитрий",
      },
      {
        id: "seed3",
        time: "2 сентября, 18:10",
        scope: "lora-of · Посты и комментарии",
        title: "Сбор выключен",
        detail: "Сохранённые данные остались доступны",
        actor: "Дмитрий",
      },
    ],
  };
}
export function loadState() {
  try {
    const data = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (
      data?.version === 1 &&
      data.pages?.["lora-of"]?.policies?.traffic &&
      Array.isArray(data.history) &&
      Array.isArray(data.jobs)
    )
      return data;
  } catch {
    /* Local prototype can work without persistent storage. */
  }
  return initialState();
}
