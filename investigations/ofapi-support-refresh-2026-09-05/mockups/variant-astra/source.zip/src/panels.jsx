import React, { useState } from "react";
import {
  Info,
  CheckCircle2,
  Calculator,
  Pause,
  LockKeyhole,
  ArrowRight,
  RotateCw,
  Download,
  History,
  Clock3,
  Archive,
  Database,
  Globe,
  File,
  Check,
  ShieldCheck,
  AlertTriangle,
  ChevronRight,
} from "lucide-react";
import { Dialog, Button, Field, Toggle } from "./ui.jsx";
import {
  modes,
  cadences,
  credits,
  num,
  validLimit,
  eventOptions,
  exampleFiles,
  TODAY,
  backgroundSpent,
  manualSpent,
} from "./data.js";

const Warning = ({ children }) => (
  <div className="notice warning">
    <AlertTriangle size={17} />
    <span>{children}</span>
  </div>
);
const Note = ({ children }) => (
  <div className="notice">
    <Info size={16} />
    <span>{children}</span>
  </div>
);
const LimitInput = ({ value, setValue, label = "Предел в день", hint }) => (
  <Field
    label={label}
    hint={hint}
    error={!validLimit(value) ? "Введите целое число от 1 до 1 000 000." : null}
  >
    <div className="input-unit">
      <input
        type="number"
        min="1"
        max="1000000"
        step="1"
        value={value}
        onChange={(e) => setValue(e.target.value)}
        aria-label={label}
        aria-invalid={!validLimit(value)}
      />
      <span>кредитов</span>
    </div>
  </Field>
);

export function CategorySheet({
  category,
  pageId,
  page,
  paused,
  close,
  onReview,
  onJob,
  jobs,
}) {
  const original = page.policies[category.id];
  const stat = page.stats[category.id];
  const [draft, setDraft] = useState({ ...original });
  const [tab, setTab] = useState("settings");
  const [discard, setDiscard] = useState(false);
  const dirty =
    draft.mode !== original.mode ||
    (draft.mode !== "off" && Number(draft.limit) !== original.limit) ||
    (draft.mode === "schedule" && draft.cadence !== original.cadence);
  const valid = draft.mode === "off" || validLimit(draft.limit);
  const requestClose = () => (dirty ? setDiscard(true) : close());
  return (
    <>
      <Dialog
        sheet
        title={category.name}
        subtitle={pageId}
        close={requestClose}
        footer={
          <>
            <div className={`save-status ${dirty ? "unsaved" : ""}`}>
              {dirty ? (
                <>
                  <span className="draft-dot" />
                  Есть несохранённые изменения
                </>
              ) : (
                <>
                  <Check size={14} />
                  Действующие настройки
                </>
              )}
            </div>
            <div className="footer-actions">
              <Button onClick={requestClose}>
                {dirty ? "Отменить" : "Закрыть"}
              </Button>
              <Button
                primary
                disabled={!dirty || !valid}
                onClick={() => onReview(draft)}
              >
                Проверить изменение
              </Button>
            </div>
          </>
        }
      >
        <div className="panel-tabs" aria-label="Раздел категории">
          <button
            aria-pressed={tab === "settings"}
            onClick={() => setTab("settings")}
          >
            Настройки
          </button>
          <button aria-pressed={tab === "data"} onClick={() => setTab("data")}>
            Запуски и данные
          </button>
        </div>
        {tab === "settings" ? (
          <>
            <p className="panel-intro">{category.purpose}</p>
            <fieldset className="mode-options">
              <legend>Режим сбора</legend>
              {Object.entries(modes)
                .filter(([id]) => !category.manualOnly || id !== "schedule")
                .map(([id, name]) => (
                  <label
                    className={`mode-option ${draft.mode === id ? "chosen" : ""}`}
                    key={id}
                  >
                    <input
                      type="radio"
                      name="collection-mode"
                      value={id}
                      checked={draft.mode === id}
                      onChange={() => setDraft({ ...draft, mode: id })}
                    />
                    <span>
                      <strong>{name}</strong>
                      <small>
                        {id === "off"
                          ? "Сохранённые данные останутся доступны"
                          : id === "manual"
                            ? "Когда данные нужны для работы"
                            : "Автоматически с выбранной частотой"}
                      </small>
                    </span>
                  </label>
                ))}
            </fieldset>
            {draft.mode === "schedule" && (
              <Field label="Частота">
                <select
                  aria-label="Частота"
                  value={draft.cadence}
                  onChange={(e) =>
                    setDraft({ ...draft, cadence: e.target.value })
                  }
                >
                  {Object.entries(cadences).map(([id, label]) => (
                    <option key={id} value={id}>
                      {label}
                    </option>
                  ))}
                </select>
              </Field>
            )}
            {draft.mode !== "off" && (
              <LimitInput
                value={draft.limit}
                setValue={(limit) => setDraft({ ...draft, limit })}
                hint={
                  draft.mode === "schedule"
                    ? `Также действует лимит фона страницы — ${credits(page.limit)} в день.`
                    : "Ручные обновления учитываются отдельно от фонового бюджета."
                }
              />
            )}
            {draft.mode !== "off" && paused && draft.mode === "schedule" && (
              <Warning>
                Фон страницы остановлен. Расписание начнёт работать после снятия
                паузы и при доступном бюджете.
              </Warning>
            )}
            <section className="panel-section">
              <h3>Что будет сохранено</h3>
              <ul className="check-list">
                {category.contents.map((line) => (
                  <li key={line}>
                    <CheckCircle2 size={16} />
                    <span>{line}</span>
                  </li>
                ))}
              </ul>
              <p className="helper">Сами файлы не скачиваются.</p>
            </section>
            {draft.mode !== "off" && (
              <div className="estimate-box">
                <Calculator size={19} />
                <div>
                  <strong>
                    {stat.background + stat.manual > 0
                      ? "Расход зависит от объёма данных"
                      : "Оценка: пока нет замеров"}
                  </strong>
                  <p>
                    {stat.background + stat.manual > 0
                      ? `Сегодня по категории: ${credits(stat.background + stat.manual)} Это факт за день, не прогноз.`
                      : "Первый сбор будет ограничен заданным бюджетом. Затем появится оценка по фактическому расходу."}
                  </p>
                </div>
              </div>
            )}
            <Note>
              Старая история не догрузится автоматически. Для неё нужен
              отдельный запуск.
            </Note>
          </>
        ) : (
          <>
            <div className="data-stat">
              <Archive size={22} />
              <div>
                <strong>{num(stat.count)} записей</strong>
                <span>
                  {stat.updated
                    ? `Последнее обновление: ${stat.updated}`
                    : "Данных пока нет"}
                </span>
              </div>
              <span className="scope-badge">Сохранено</span>
            </div>
            <div className="cost-pair">
              <div>
                <span>Фон сегодня</span>
                <strong>{credits(stat.background)}</strong>
              </div>
              <div>
                <span>Ручные запросы</span>
                <strong>{credits(stat.manual)}</strong>
              </div>
            </div>
            <section className="panel-section">
              <h3>Разовые задачи</h3>
              <p className="helper">
                Каждый запуск требует отдельного лимита и подтверждения.
                Регулярные настройки не меняются.
              </p>
              <div className="action-list">
                <button disabled={dirty} onClick={() => onJob("refresh")}>
                  <RotateCw size={17} />
                  <span>
                    Обновить сейчас<small>Получить текущие данные</small>
                  </span>
                  <ChevronRight size={16} />
                </button>
                <button disabled={dirty} onClick={() => onJob("history")}>
                  <History size={17} />
                  <span>
                    Догрузить историю<small>За выбранный период</small>
                  </span>
                  <ChevronRight size={16} />
                </button>
                {category.id === "vault" && (
                  <button disabled={dirty} onClick={() => onJob("download")}>
                    <Download size={17} />
                    <span>
                      Скачать выбранные файлы
                      <small>Отдельно от каталога медиа</small>
                    </span>
                    <ChevronRight size={16} />
                  </button>
                )}
              </div>
              {dirty && (
                <Note>Сначала примените или отмените изменения настроек.</Note>
              )}
            </section>
            <section className="panel-section">
              <h3>Последние разовые запуски</h3>
              {jobs.length ? (
                jobs.map((job) => (
                  <div key={job.id} className="mini-job">
                    <CheckCircle2 size={16} />
                    <div>
                      <strong>{job.title}</strong>
                      <span>
                        {job.scopeText} · {credits(job.cost)}
                      </span>
                    </div>
                  </div>
                ))
              ) : (
                <div className="empty-state">
                  <Clock3 size={24} />
                  <strong>Разовых запусков ещё не было</strong>
                  <p>Здесь появятся их статус, объём и расход.</p>
                </div>
              )}
            </section>
          </>
        )}
      </Dialog>
      {discard && (
        <Dialog
          title="Отменить изменения?"
          subtitle={category.name}
          close={() => setDiscard(false)}
          footer={
            <>
              <Button onClick={() => setDiscard(false)}>
                Продолжить редактирование
              </Button>
              <Button primary onClick={close}>
                Отменить изменения
              </Button>
            </>
          }
        >
          <p className="body-copy">
            Новые настройки не применены. Категория продолжит работать в прежнем
            режиме.
          </p>
        </Dialog>
      )}
    </>
  );
}

export function BudgetDialog({ page, pageId, close, review }) {
  const [limit, setLimit] = useState(page.limit);
  const spent = backgroundSpent(page);
  const submit = () =>
    review({
      title: "Изменить лимит фона",
      scope: pageId,
      diffs: [
        [
          "Дневной лимит",
          `${credits(page.limit)} в день`,
          `${credits(limit)} в день`,
        ],
      ],
      note: "Лимит общий для всех категорий этой страницы, работающих по расписанию. Он проверяется перед новым платным запросом.",
      cost:
        Number(limit) <= spent
          ? `Уже потрачено ${credits(spent)} Новые фоновые запросы остановятся до следующего дня по UTC.`
          : `На оставшуюся часть дня будет доступно ${credits(Number(limit) - spent)} Уже выполняющиеся запросы могут завершиться.`,
      apply: (next) => {
        next.pages[pageId].limit = Number(limit);
      },
    });
  return (
    <Dialog
      title="Лимит фонового сбора"
      subtitle={pageId}
      close={close}
      footer={
        <>
          <Button onClick={close}>Отменить</Button>
          <Button
            primary
            disabled={!validLimit(limit) || Number(limit) === page.limit}
            onClick={submit}
          >
            Проверить изменение
          </Button>
        </>
      }
    >
      <p className="body-copy">
        Максимум на новые запросы по расписанию. При достижении лимита сбор
        дождётся следующего дня.
      </p>
      <LimitInput label="Дневной лимит" value={limit} setValue={setLimit} />
      <div className="presets">
        {[100, 300, 500].map((v) => (
          <button
            key={v}
            onClick={() => setLimit(v)}
            aria-pressed={Number(limit) === v}
          >
            {num(v)} кр.
          </button>
        ))}
      </div>
      <div className="detail-line">
        <span>Уже потрачено сегодня</span>
        <strong>{credits(spent)}</strong>
      </div>
      {validLimit(limit) && Number(limit) <= spent && (
        <Warning>
          Новый лимит уже достигнут. Фоновые запросы остановятся после
          применения.
        </Warning>
      )}
      <Note>
        Ручные обновления, разовые задачи и события OFAPI имеют отдельный учёт.
        Этот лимит не ограничивает весь расход аккаунта OFAPI.
      </Note>
    </Dialog>
  );
}

export function PauseDialog({ state, pageId, close, review }) {
  const paused = state.globalPaused || state.pages[pageId].paused;
  const [scope, setScope] = useState(state.globalPaused ? "all" : "page");
  const target = scope === "all" ? "Все OF-страницы" : pageId;
  const submit = () =>
    review({
      title: paused ? "Возобновить фоновый сбор" : "Приостановить фоновый сбор",
      scope: target,
      diffs: [
        [
          "Фоновый сбор",
          paused ? "На паузе" : "Работает по настройкам",
          paused ? "Работает по настройкам" : "На паузе",
        ],
      ],
      note: paused
        ? "Сбор продолжится в пределах действующих лимитов. Пропущенная история не загрузится автоматически."
        : "Новые фоновые запросы остановятся. Настройки, архив и точки продолжения сохранятся; уже начатые запросы могут завершиться.",
      cost: "Ручные запросы и входящие события OFAPI продолжают работать и расходуют кредиты отдельно.",
      apply: (next) => {
        if (scope === "all") next.globalPaused = !paused;
        else next.pages[pageId].paused = !paused;
      },
    });
  return (
    <Dialog
      title={paused ? "Возобновить фон" : "Поставить фон на паузу"}
      close={close}
      footer={
        <>
          <Button onClick={close}>Отменить</Button>
          <Button primary onClick={submit}>
            Проверить изменение
          </Button>
        </>
      }
    >
      <p className="body-copy">
        {paused
          ? "Снять действующую паузу фонового сбора."
          : "Выберите, где остановить новые запросы по расписанию."}
      </p>
      <fieldset className="mode-options">
        <legend>Область действия</legend>
        {(paused ? [scope] : ["page", "all"]).map((id) => (
          <label
            className={`mode-option ${scope === id ? "chosen" : ""}`}
            key={id}
          >
            <input
              type="radio"
              name="pause-scope"
              checked={scope === id}
              onChange={() => setScope(id)}
            />
            <span>
              <strong>
                {id === "page" ? `Только ${pageId}` : "Все OF-страницы"}
              </strong>
              <small>
                {id === "page"
                  ? "Другие страницы продолжат работать"
                  : "Общая пауза фонового сбора"}
              </small>
            </span>
          </label>
        ))}
      </fieldset>
      {state.globalPaused && (
        <Note>
          Индивидуальные паузы страниц сохранятся после снятия общей паузы.
        </Note>
      )}
      <div className="panel-section">
        <h3>Продолжат работать</h3>
        <ul className="check-list">
          <li>
            <CheckCircle2 size={16} />
            Действия чаттеров и ручные запросы
          </li>
          <li>
            <CheckCircle2 size={16} />
            События OFAPI и уже запущенные задачи
          </li>
          <li>
            <CheckCircle2 size={16} />
            Поиск по сохранённому архиву
          </li>
        </ul>
      </div>
    </Dialog>
  );
}

export function EventsDialog({ events, close, review }) {
  const [draft, setDraft] = useState({ ...events });
  const changes = eventOptions.filter((e) => draft[e.id] !== events[e.id]);
  const submit = () =>
    review({
      title: "Изменить события OFAPI",
      scope: "Все OF-страницы",
      diffs: changes.map((e) => [
        e.name,
        events[e.id] ? "Включено" : "Выключено",
        draft[e.id] ? "Включено" : "Выключено",
      ]),
      note: "Изменение действует на все OF-страницы. Выключенные события перестанут поступать; пропуски не восстановятся автоматически.",
      cost: "События учитываются отдельно от лимита фонового сбора. Стоимость зависит от числа доставок; счётчики ниже — иллюстративные данные.",
      apply: (next) => {
        next.events = { ...draft };
      },
    });
  return (
    <Dialog
      wide
      title="События OFAPI"
      subtitle="Общие настройки для всех OF-страниц"
      close={close}
      footer={
        <>
          <Button onClick={close}>Отменить</Button>
          <Button primary disabled={!changes.length} onClick={submit}>
            Проверить изменение
          </Button>
        </>
      }
    >
      <div className="global-notice">
        <Globe size={18} />
        <div>
          <strong>Эта настройка общая</strong>
          <p>Она применяется и к lora-of, и к lora-vip-of.</p>
        </div>
      </div>
      <section className="panel-section core-events">
        <div className="section-inline">
          <h3>События для работы Hub</h3>
          <span className="scope-badge">
            <LockKeyhole size={12} />
            Обязательные
          </span>
        </div>
        <p>
          Сообщения, покупки, состояние аккаунта и завершение задач. Они
          поддерживают работу чатов и актуальность данных.
        </p>
      </section>
      <div className="section-heading">
        <h3>Дополнительные события</h3>
        <span>Сегодня · пример</span>
      </div>
      <div className="event-options">
        {eventOptions.map((e) => (
          <div className="event-option" key={e.id}>
            <div>
              <strong>{e.name}</strong>
              <p>{e.description}</p>
              <small>
                {num(e.count)} событий
                {e.count > 0
                  ? ` · ≈ ${credits(e.cost)}`
                  : " · расход пока неизвестен"}
              </small>
            </div>
            <Toggle
              label={e.name}
              checked={draft[e.id]}
              onChange={(v) => setDraft({ ...draft, [e.id]: v })}
            />
          </div>
        ))}
      </div>
      <Note>
        Частота событий не равна их полезности. Перед выключением учитывайте
        функции Hub, которым они нужны.
      </Note>
    </Dialog>
  );
}

export function HistoryDialog({ history, close }) {
  return (
    <Dialog
      wide
      title="История изменений"
      subtitle="Настройки всех OF-страниц"
      close={close}
      footer={<Button onClick={close}>Закрыть</Button>}
    >
      <div className="history-list">
        {history.map((entry) => (
          <article key={entry.id}>
            <span className="history-icon">
              <History size={16} />
            </span>
            <div>
              <div className="history-meta">
                <span>{entry.time}</span>
                <span>{entry.actor}</span>
              </div>
              <strong>{entry.title}</strong>
              <span className="history-scope">{entry.scope}</span>
              <p>{entry.detail}</p>
            </div>
          </article>
        ))}
      </div>
    </Dialog>
  );
}

export function SpendDialog({ page, pageId, close }) {
  return (
    <Dialog
      title="Расход сегодня"
      subtitle={`${pageId} · день по UTC`}
      close={close}
      footer={<Button onClick={close}>Закрыть</Button>}
    >
      <div className="expense-total">
        <span>Запросы этой страницы</span>
        <strong>{credits(backgroundSpent(page) + manualSpent(page))}</strong>
      </div>
      <div className="expense-row">
        <div>
          <span className="expense-dot background-dot" />
          Фоновый сбор
        </div>
        <strong>{credits(backgroundSpent(page))}</strong>
      </div>
      <p className="expense-caption">
        В пределах общего лимита {credits(page.limit)} в день
      </p>
      <div className="expense-row">
        <div>
          <span className="expense-dot manual-dot" />
          Ручные запросы и разовые задачи
        </div>
        <strong>{credits(manualSpent(page))}</strong>
      </div>
      <p className="expense-caption">Отдельно от лимита фона</p>
      <section className="panel-section">
        <div className="expense-row">
          <div>
            События OFAPI<span className="scope-badge">Все OF-страницы</span>
          </div>
          <strong>≈ 7 кр.</strong>
        </div>
        <p className="helper">
          Отдельный общий расход по доставкам, включая обязательные события.
          Пример, не реальное списание.
        </p>
      </section>
      <Note>
        Верхний лимит страницы покрывает только её фоновые запросы. Действия из
        других приложений с тем же API-ключом сюда не входят.
      </Note>
    </Dialog>
  );
}

export function JobDialog({ kind, category, pageId, close, review }) {
  const [limit, setLimit] = useState(kind === "download" ? 15 : 20);
  const [start, setStart] = useState("2026-08-29");
  const [end, setEnd] = useState(TODAY);
  const [files, setFiles] = useState([]);
  const [consent, setConsent] = useState(false);
  const title =
    kind === "history"
      ? "Догрузить историю"
      : kind === "download"
        ? "Скачать выбранные файлы"
        : "Обновить сейчас";
  const fileCost = exampleFiles
    .filter((f) => files.includes(f.id))
    .reduce((n, f) => n + Math.max(1, Math.ceil(f.size * 3)), 0);
  const dateValid = Boolean(start && end && start <= end && end <= TODAY);
  const valid =
    validLimit(limit) &&
    consent &&
    (kind !== "history" || dateValid) &&
    (kind !== "download" || (files.length > 0 && Number(limit) >= fileCost));
  const scopeText =
    kind === "history"
      ? `${start.split("-").reverse().join(".")} — ${end.split("-").reverse().join(".")}`
      : kind === "download"
        ? `${files.length} файла · ${num(exampleFiles.filter((f) => files.includes(f.id)).reduce((n, f) => n + f.size, 0))} МБ`
        : "Текущие данные";
  const submit = () => {
    const job = {
      id: crypto.randomUUID(),
      pageId,
      categoryId: category.id,
      title: `${title} · ${category.name}`,
      scopeText,
      limit: Number(limit),
      cost:
        kind === "download"
          ? fileCost
          : Math.min(Number(limit), kind === "history" ? 8 : 2),
      status: "running",
    };
    review({
      title: "Запустить разовую задачу",
      scope: `${pageId} · ${category.name}`,
      diffs: [
        ["Действие", "Не запущено", title],
        ["Объём", "—", scopeText],
        ["Лимит задачи", "—", credits(limit)],
      ],
      note: "Этот запуск не включает регулярный сбор и не меняет дневные лимиты категории. Данные в прототипе имитируются, API не вызывается.",
      cost:
        kind === "download"
          ? `Оценка выбранных файлов: ${credits(fileCost)} по модели 3 кр./МБ с округлением вверх для каждого файла. В прототипе файлы не скачиваются.`
          : `Стоимость заранее неизвестна. Задача остановится до запроса, который не помещается в оставшийся лимит ${credits(limit)}`,
      job,
      success: "Разовая задача запущена в режиме примера",
      apply: (next) => {
        next.jobs.unshift(job);
      },
    });
  };
  return (
    <Dialog
      title={title}
      subtitle={`${pageId} · ${category.name}`}
      close={close}
      footer={
        <>
          <Button onClick={close}>Отменить</Button>
          <Button primary disabled={!valid} onClick={submit}>
            Проверить запуск
          </Button>
        </>
      }
    >
      <p className="body-copy">
        {kind === "history"
          ? "Выберите период. Сбор остановится при исчерпании лимита; полученные данные сохранятся."
          : kind === "download"
            ? "Выберите конкретные файлы. Их загрузка оплачивается отдельно от обновления каталога."
            : "Один раз получить свежие данные в пределах отдельного бюджета."}
      </p>
      {kind === "history" && (
        <>
          <div className="date-range">
            <Field label="С даты">
              <input
                type="date"
                aria-label="С даты"
                value={start}
                max={end || TODAY}
                onInput={(e) => setStart(e.currentTarget.value)}
                onChange={(e) => setStart(e.target.value)}
                onBlur={(e) => setStart(e.target.value)}
              />
            </Field>
            <Field label="По дату">
              <input
                type="date"
                aria-label="По дату"
                value={end}
                min={start}
                max={TODAY}
                onInput={(e) => setEnd(e.currentTarget.value)}
                onChange={(e) => setEnd(e.target.value)}
                onBlur={(e) => setEnd(e.target.value)}
              />
            </Field>
          </div>
          {!dateValid && (
            <p className="field-error" role="alert">
              Выберите корректный период, без будущих дат.
            </p>
          )}
        </>
      )}
      {kind === "download" && (
        <>
          <div className="file-list">
            {exampleFiles.map((file) => (
              <label key={file.id}>
                <input
                  type="checkbox"
                  checked={files.includes(file.id)}
                  onChange={(e) =>
                    setFiles(
                      e.target.checked
                        ? [...files, file.id]
                        : files.filter((id) => id !== file.id),
                    )
                  }
                />
                <File size={18} />
                <span>
                  {file.name}
                  <small>{num(file.size)} МБ</small>
                </span>
              </label>
            ))}
          </div>
          <div className="detail-line">
            <span>Оценка выбранных файлов</span>
            <strong>{credits(fileCost)}</strong>
          </div>
        </>
      )}
      <LimitInput
        label="Лимит этой задачи"
        value={limit}
        setValue={setLimit}
        hint="Разовый бюджет, не увеличение дневного лимита фона."
      />
      {kind === "download" && files.length > 0 && Number(limit) < fileCost && (
        <Warning>
          Лимита не хватит на выбранные файлы. Уменьшите выбор или измените
          бюджет.
        </Warning>
      )}
      <label className="consent">
        <input
          type="checkbox"
          checked={consent}
          onChange={(e) => setConsent(e.target.checked)}
        />
        <span>Разрешить эту разовую платную задачу в указанном объёме</span>
      </label>
    </Dialog>
  );
}

export function ReviewDialog({ review, close, apply, busy }) {
  return (
    <Dialog
      title="Проверка изменения"
      subtitle={review.scope}
      close={close}
      footer={
        <>
          <Button disabled={busy} onClick={close}>
            Назад
          </Button>
          <Button primary loading={busy} onClick={apply}>
            {busy
              ? "Применяем…"
              : review.job
                ? "Подтвердить запуск"
                : "Применить изменение"}
          </Button>
        </>
      }
    >
      <h3 className="review-title">{review.title}</h3>
      <div className="review-diffs">
        {review.diffs.map(([name, from, to]) => (
          <div className="review-diff" key={name}>
            <span>{name}</span>
            <div>
              <span className="diff-before">{from}</span>
              <ArrowRight size={14} />
              <strong>{to}</strong>
            </div>
          </div>
        ))}
      </div>
      <section className="panel-section">
        <h3>После применения</h3>
        <p className="body-copy">{review.note}</p>
      </section>
      <div className="estimate-box">
        <Calculator size={19} />
        <div>
          <strong>Как это повлияет на расход</strong>
          <p>{review.cost}</p>
        </div>
      </div>
      <p className="review-audit">
        <ShieldCheck size={15} />
        Изменение будет записано в историю
      </p>
    </Dialog>
  );
}
