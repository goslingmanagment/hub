# Prototype Instructions

This is a standalone, interactive AgencyHub collection-control prototype. Use Russian copy and the existing Hub light Anthropic-inspired palette: warm off-white background, white grouped surfaces, terracotta accent, Inter. User explicitly asked for coded UI, not generated images; do not generate more mock images. Use local example data only. Do not call OFAPI, deploy, or change the Hub repository. Preserve separation between background limits, manual tasks, global event subscriptions, stored archives and binary downloads.

Run the local server yourself and open the preview in the browser available to this environment. Do not give the user server-start instructions when you can run it.

Before making substantial visual changes, use the Product Design plugin's `get-context` skill when the visual source is unclear or no longer matches the current goal. When the user gives durable prototype-specific design feedback, preferences, or decisions, record them in `AGENTS.md`.

When implementing from a selected generated mock, treat that image as the source of truth for layout, component anatomy, density, spacing, color, typography, visible content, and hierarchy.

Build app UI in `src/`. Keep `.openai/hosting.json`, `worker/index.js`, `scripts/prepare-sites-build.mjs`, and `tests/sites-worker.test.mjs` intact so the same local prototype can be handed to Sites. Before a Sites handoff, run `npm run build` and `npm run test:sites`; the build must leave `dist/client/index.html`, `dist/server/index.js`, and `dist/.openai/hosting.json`.

This archived variant is a non-normative mockup, not part of the implementation plan. Do not treat it as approval to implement the UI or change production.
